@extends("website.index")
@section('conteudo')
<h1 class="text-center">Historico de consultas</h1>

<div class="col-8 m-auto">
<table class="table text-center">
  <thead class="table-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nome do cliente</th>
      <th scope="col">Nome do Pet</th>
      <th scope="col">Detalhe da consulta</th>
      <th scope="col">Diagnostico</th>
      <th class="col">Tratamento</th>
      <th class="col">Prescrições</th>
      <th class="col">Ações</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>
        <input class="btn btn-primary" value="editar">
        <input class="btn btn-danger" value="remover">
      </td>
    </tr>
</table>
</div>
@endsection