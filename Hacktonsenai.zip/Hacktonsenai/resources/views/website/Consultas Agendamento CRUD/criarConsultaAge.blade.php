@extends("website.index")
@section('conteudo')
<h1 class="text-center">Agendar Consulta</h1>
<div class="col-8 m-auto">
    <input class="form-control" type="date" name="nome" id="nome" placeholder="Data:"><br />
    <input class="form-control" type="time" name="descrição" id="descrição" placeholder="Hora:"><br />
    <input class="form-control" type="text" name="preço" id="preço" placeholder="Nome do Cliente:"><br />
    <input class="form-control" type="text" name="estoque" id="estoque" placeholder="Nome do Pet:"><br />
    <input class="btn btn-primary" type="submit" value="Adicionar"
        onclick='location.href="/administrador/adicionarproduto"'>
</div>
@endsection