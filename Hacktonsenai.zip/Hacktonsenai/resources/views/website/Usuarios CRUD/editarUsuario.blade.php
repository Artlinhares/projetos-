@extends("website.index")
@section('conteudo')
<h1 class="text-center">Editar Usuarios</h1>
    <div class="col-8 m-auto">
        <input class="form-control" type="text" name="nome" id="nome" placeholder="Nome:"><br />
        <input class="form-control" type="text" name="descrição" id="descrição" placeholder="Email:"><br />
        <input class="form-control" type="text" name="preço" id="preço" placeholder="Senha:"><br />

        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
        <label class="form-check-label" for="flexRadioDefault1">
          Administrador
        </label>
        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
        <label class="form-check-label" for="flexRadioDefault1">
          Veterinario
        </label>
        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
        <label class="form-check-label" for="flexRadioDefault1">
          Funcionario
        </label> <br/>
        <br/>

        <input class="btn btn-primary" type="submit" value="Adicionar" onclick='location.href="/administrador/adicionarproduto"'><br />
    </div>
@endsection