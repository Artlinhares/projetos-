@extends("website.index")
@section('conteudo')
<h1 class="text-center">Clientes</h1>

<div class="col-8 m-auto">
<table class="table text-center">
  <thead class="table-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nome</th>
      <th scope="col">Email</th>
      <th scope="col">Tipo</th>
      <th scope="col">Email</th>
      <th class="col">Ações</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td>
        <input class="btn btn-primary" value="editar">
        <input class="btn btn-danger" value="remover">
      </td>
    </tr>
</table>
</div>
@endsection