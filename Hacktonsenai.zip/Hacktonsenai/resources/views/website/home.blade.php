@extends('website.index')
@section('conteudo')

    <body class="w3-light-grey">

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer"
            title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left:300px;margin-top:43px;">

            <!-- Header -->
            <header class="w3-container" style="padding-top:22px">
                <h5><b>Informações Gerais <br> 12/08/2023</b></h5>
            </header>

            <div class="w3-row-padding w3-margin-bottom">
                <div class="w3-quarter">
                    <div class="w3-container w3-red w3-padding-16">
                        <div class="w3-left"><i class="fa fa-user w3-xxxlarge"></i></div>
                        <div class="w3-right">
                            <h3>30</h3>
                        </div>
                        <div class="w3-clear"></div>
                        <h4>Clientes</h4>
                    </div>
                </div>
                <div class="w3-quarter">
                    <div class="w3-container w3-blue w3-padding-16">
                        <div class="w3-left"><i class="fas fa-list w3-xxxlarge"></i></div>
                        <div class="w3-right">
                            <h3>34</h3>
                        </div>
                        <div class="w3-clear"></div>
                        <h4>Pets</h4>
                    </div>
                </div>
                <div class="w3-quarter">
                    <div class="w3-container w3-teal w3-padding-16">
                        <div class="w3-left"><i class="fa fa-share-alt w3-xxxlarge"></i></div>
                        <div class="w3-right">
                            <h3>10</h3>
                        </div>
                        <div class="w3-clear"></div>
                        <h4>Consultas</h4>
                    </div>
                </div>
                <div class="w3-quarter">
                    <div class="w3-container w3-orange w3-text-white w3-padding-16">
                        <div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>
                        <div class="w3-right">
                            <h3>6</h3>
                        </div>
                        <div class="w3-clear"></div>
                        <h4>Usuários</h4>
                    </div>
                </div>
            </div>

            <div class="w3-panel">
                <div class="w3-row-padding" style="margin:0 -16px">
                    <div class="w3-twothird">
                        <h5>Programação <br> 12/08/2023</h5>
                        <table class="w3-table w3-striped w3-white">
                            <tr>
                                <td><i class="fa fa-user w3-text-blue w3-large"></i></td>
                                <td>Consulta de Elizabeth III / Belinha</td>
                                <td><i>12:40</i></td>
                            </tr>
                            <tr>
                                <td><i class="fa fa-user w3-text-red w3-large"></i></td>
                                <td>Consulta do Marcel / Mel</td>
                                <td><i>14:00</i></td>
                            </tr>
                            <tr>
                                <td><i class="fa fa-user w3-text-green w3-large"></i></td>
                                <td>Consulta do Samuel / Loro</td>
                                <td><i>15:00</i></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <hr>
            <div class="w3-container">
                <h5>Status Gerais</h5>
                <p>Novos Clientes</p>
                <div class="w3-grey">
                    <div class="w3-container w3-center w3-padding w3-green" style="width:25%">+25%</div>
                </div>

                <p>Novos Pets</p>
                <div class="w3-grey">
                    <div class="w3-container w3-center w3-padding w3-orange" style="width:50%">50%</div>
                </div>

                <p>Ganhos</p>
                <div class="w3-grey">
                    <div class="w3-container w3-center w3-padding w3-red" style="width:75%">75%</div>
                </div>
            </div>
        </div><br>

        <!-- End page content -->

        <script>
            // Get the Sidebar
            var mySidebar = document.getElementById("mySidebar");

            // Get the DIV with overlay effect
            var overlayBg = document.getElementById("myOverlay");

            // Toggle between showing and hiding the sidebar, and add overlay effect
            function w3_open() {
                if (mySidebar.style.display === 'block') {
                    mySidebar.style.display = 'none';
                    overlayBg.style.display = "none";
                } else {
                    mySidebar.style.display = 'block';
                    overlayBg.style.display = "block";
                }
            }

            // Close the sidebar with the close button
            function w3_close() {
                mySidebar.style.display = "none";
                overlayBg.style.display = "none";
            }
        </script>

    </body>

    </html>
@endsection
