@extends('website.index')
@section('conteudo')
<h1 class="text-center">Editar Pets</h1>
    <div class="col-8 m-auto">
        <input class="form-control" type="text" name="nome" id="nome" placeholder="Nome do pet:"><br />
        <input class="form-control" type="text" name="descrição" id="descrição" placeholder="Raça:"><br />
        <input class="form-control" type="text" name="preço" id="preço" placeholder="Idade:"><br />
        <input class="form-control" type="text" name="estoque" id="estoque" placeholder="Historico de saude:"><br />
        <input class="btn btn-primary" type="submit" value="Adicionar"
            onclick='location.href="/administrador/adicionarproduto"'>
    </div>
@endsection