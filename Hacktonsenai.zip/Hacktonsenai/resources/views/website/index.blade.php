<!DOCTYPE html>
<html>
<head>
<title>Unimed Pets</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar">
    <hr>
    <div class="w3-container" style="text-align: center">
      <h5><img src="/img/logo.png" alt="" width="120px" height="120px"></h5>
    </div>
    <div class="w3-bar-block">
      <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
      <div class="w3-dropdown-hover w3-hide-small">
        <button class="w3-button w3-padding-large" title="Cadastrar"><i class=""></i> Cadastrar<span class="w3-badge w3-right w3-small w3-green">1</span></button>     
        <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
          <a href="#" class="w3-bar-item w3-button">Cadastrar Cliente</a>
          <a href="#" class="w3-bar-item w3-button">Cadastrar Pet</a>
          <a href="#" class="w3-bar-item w3-button">Agendar Consulta</a>
          <a href="#" class="w3-bar-item w3-button">Cadastrar Usuário</a>
        </div>
      </div>
      <div class="w3-dropdown-hover w3-hide-small">
        <button class="w3-button w3-padding-large" title="Cadastrar"><i class=""></i> Listar<span class="w3-badge w3-right w3-small w3-green"></span></button>     
        <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
          <a href="#" class="w3-bar-item w3-button">Listar Cliente</a>
          <a href="#" class="w3-bar-item w3-button">Listar Pet</a>
          <a href="#" class="w3-bar-item w3-button">Listar Consulta</a>
          <a href="#" class="w3-bar-item w3-button">Listar Usuário</a>
        </div>
      </div>
      <div class="w3-dropdown-hover w3-hide-small">
        <button class="w3-button w3-padding-large" title="Cadastrar"><i class=""></i> Editar<span class="w3-badge w3-right w3-small w3-green"></span></button>     
        <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
          <a href="#" class="w3-bar-item w3-button">Editar Cliente</a>
          <a href="#" class="w3-bar-item w3-button">Editar Pet</a>
          <a href="#" class="w3-bar-item w3-button">Editar Consulta</a>
          <a href="#" class="w3-bar-item w3-button">Editar Usuário</a>
        </div>
      </div>
      <div class="w3-dropdown-hover w3-hide-small">
        <button class="w3-button w3-padding-large" title="Cadastrar"><i class=""></i> Deletar<span class="w3-badge w3-right w3-small w3-green"></span></button>     
        <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
          <a href="#" class="w3-bar-item w3-button">Deletar Cliente</a>
          <a href="#" class="w3-bar-item w3-button">Deletar Pet</a>
          <a href="#" class="w3-bar-item w3-button">Deletar Consulta</a>
          <a href="#" class="w3-bar-item w3-button">Deletar Usuário</a>
        </div>
      </div>
    </div>
  </nav>
       <!-- Top container -->
       <div class="w3-bar w3-top w3-white w3-large" style="z-index:4">
        <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i
                class="fa fa-bars"></i>  Menu</button>
        <span class="w3-bar-item w3-right">Unimed Pets</span>
    </div>
<body>
  @yield('conteudo')
</body>
</html>