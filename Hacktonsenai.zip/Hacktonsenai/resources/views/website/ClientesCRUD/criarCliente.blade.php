@extends("website.index")
@section('conteudo')
    <!--  -->
    <h1 class="text-center">Cadastrar Cliente</h1>
    <div class="col-8 m-auto">
        <input class="form-control" type="text" name="nome" id="nome" placeholder="Nome"><br />
        <input class="form-control" type="text" name="descrição" id="descrição" placeholder="Endereço:"><br />
        <input class="form-control" type="text" name="preço" id="preço" placeholder="Telefone:"><br />
        <input class="form-control" type="text" name="estoque" id="estoque" placeholder="Email:"><br />
        <input class="form-control" type="text" name="estoque" id="estoque" placeholder="senha:"><br />
        <input class="btn btn-primary" type="submit" value="Adicionar"
            onclick='location.href="/administrador/adicionarproduto"'>
    </div>    
@endsection