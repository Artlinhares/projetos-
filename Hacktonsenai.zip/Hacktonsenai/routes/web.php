<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/login', 'App\Http\Controllers\Website\WebsiteControllers@login'); 
Route::get('/', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/cadastrarcliente', 'App\Http\Controllers\Website\WebsiteControllers@cadastrarcliente'); 
Route::get('/cadastrarpacientes', 'App\Http\Controllers\Website\WebsiteControllers@cadastrarpacientes'); 
Route::get('/cadastrarconsultas', 'App\Http\Controllers\Website\WebsiteControllers@cadastrarconsultas'); 
Route::get('/registroconsulta', 'App\Http\Controllers\Website\WebsiteControllers@registroconsulta'); 
Route::get('/cadastrousuario', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/listarcliente', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/listarpacientes', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/listarconsultas', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/listarusuarios', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/editarcliente', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/editarpacientes', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/editarconsultas', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/editarusuario', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/deletarcliente', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/deletarpacientes', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/deletarconsultas', 'App\Http\Controllers\Website\WebsiteControllers@home'); 
Route::get('/deletarusuario', 'App\Http\Controllers\Website\WebsiteControllers@home'); 



