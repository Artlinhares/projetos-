<?php
namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;


class WebsiteControllers extends Controller
{
    public function login(){
        return view("website.login");
    }
    public function home(){
        return view("website.home");
    }
    public function cadastrarcliente(){
        return view("website.cadastrarcliente");
    }
    public function cadastrarpacientes(){
        return view("website.home");
    }
    public function cadastrarconsultas(){
        return view("website.home");
    }
    public function registroconsulta(){
        return view("website.home");
    }
    public function cadastrousuario(){
        return view("website.home");
    }
    public function listarcliente(){
        return view("website.home");
    }
    public function listarpacientes(){
        return view("website.home");
    }
    public function listarconsultas(){
        return view("website.home");
    }
    public function listarusuarios(){
        return view("website.home");
    }
    public function editarcliente(){
        return view("website.home");
    }
    public function editarpacientes(){
        return view("website.home");
    }
    public function editarconsultas(){
        return view("website.home");
    }
    public function editarusuario(){
        return view("website.home");
    }
    public function deletarcliente(){
        return view("website.home");
    }
    public function deletarpacientes(){
        return view("website.home");
    }
    public function deletarconsultas(){
        return view("website.home");
    }
    public function deletarusuario(){
        return view("website.home");
    }


}
